﻿$(document).ready(function () {
    setTimeout(
        function () {
            $(".slideanim").each(function () {
                $(this).addClass("slideUp");
            });
        }, 300);
});
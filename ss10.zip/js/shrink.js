﻿window.onscroll = function () { scrollFunction() };

function scrollFunction() {
    if (document.body.scrollTop > 40 || document.documentElement.scrollTop > 80) {
        document.getElementById("navbar-brand").setAttribute('style', "width:113px;");
        document.getElementById("navbar-brand").style.transition = "width.5s";
        document.getElementById("navbar-brand").style.transitionTimingFunction = "cubic - bezier(0.4, 0, 0.2, 1)";
        document.getElementById("navbar").setAttribute('style', 'background-color: #00000080');
    } else {
        document.getElementById("navbar-brand").setAttribute('style', "width:135px;");
        document.getElementById("navbar-brand").style.transition = "width .5s";
        document.getElementById("navbar").removeAttribute('style');
    }
}

//MOBILE/DESKTOP DISCLAIMER LINKS
(function ($) {
    var $window = $(window),
        $disclaimerLinks = $('#links a.text-info');

    function resize() {
        if ($window.width() < 480) {
            return $disclaimerLinks
                .removeClass('case-study')
                .attr('target', '_blank');
        }

        $disclaimerLinks
            .addClass('case-study')
            .attr('target', '');
    }

    $window
        .resize(resize)
        .trigger('resize');
})(jQuery);
///MOBILE/DESKTOP DISCLAIMER LINKS
